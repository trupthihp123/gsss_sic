from flask import Flask, render_template, request, send_file
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # Safe backend for servers
import matplotlib.pyplot as plt
import io, base64, tempfile, json
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors

app = Flask(__name__)
processed_data = {}

@app.route('/')
def index():
    # Expect an index.html with a simple upload form posting to /upload
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    global processed_data
    if 'file' not in request.files:
        return "No file part"
    file = request.files['file']
    if file.filename == '':
        return "No selected file"

    try:
        # --- Read CSV and restrict to needed columns (your CSV may have extra summary cols) ---
        df = pd.read_csv(file)
        df = df[['caller', 'receiver', 'duration', 'call_type', 'date']]

        # Types & datetime
        # Coerce duration numeric; drop bad rows if any
        df['duration'] = pd.to_numeric(df['duration'], errors='coerce')
        df = df.dropna(subset=['duration'])
        df['duration'] = df['duration'].astype(float)

        df['date'] = pd.to_datetime(df['date'], errors='coerce')
        df = df.dropna(subset=['date'])

        # --- Summary per caller (freshly computed) ---
        summary = (
            df.groupby('caller', as_index=False)
              .agg(total_calls=('duration', 'count'),
                   total_duration=('duration', 'sum'),
                   average_duration=('duration', 'mean'))
        )

        # Merge for detailed view
        result_df = df.merge(summary, on='caller', how='left')

        # Top callers by total duration
        top_callers = summary.sort_values(by='total_duration', ascending=False).head(3)

        # Persist in memory for downloads/PDF
        processed_data['df'] = result_df.copy()
        processed_data['summary'] = summary.copy()
        processed_data['top_callers'] = top_callers.copy()

        # --- KPI values (pure Python types) ---
        kpi_data = {
            "total_calls": int(summary["total_calls"].sum()) if not summary.empty else 0,
            "total_duration": float(summary["total_duration"].sum()) if not summary.empty else 0.0,
            "avg_duration": float(summary["average_duration"].mean()) if not summary.empty else 0.0,
            "top_caller": str(top_callers["caller"].iloc[0]) if not top_callers.empty else "N/A"
        }

        # -------------------- Matplotlib graphs (for PDF) --------------------
        graphs = {}

        # Total duration per caller
        plt.figure(figsize=(8, 4))
        summary.plot(kind='bar', x='caller', y='total_duration', legend=False, color='#4CAF50')
        plt.ylabel('Total Duration (min)')
        plt.xlabel('Caller')
        plt.tight_layout()
        buf1 = io.BytesIO()
        plt.savefig(buf1, format='png'); buf1.seek(0)
        graphs['duration'] = base64.b64encode(buf1.getvalue()).decode()
        plt.close()

        # Total calls per caller
        plt.figure(figsize=(8, 4))
        summary.plot(kind='bar', x='caller', y='total_calls', legend=False, color='#2196F3')
        plt.ylabel('Total Calls')
        plt.xlabel('Caller')
        plt.tight_layout()
        buf2 = io.BytesIO()
        plt.savefig(buf2, format='png'); buf2.seek(0)
        graphs['calls'] = base64.b64encode(buf2.getvalue()).decode()
        plt.close()

        # Call type pie (matplotlib) for the PDF
        call_type_counts = df['call_type'].value_counts()
        plt.figure(figsize=(6, 6))
        call_type_counts.plot(kind='pie', autopct='%1.1f%%', colors=['#FF5722', '#4CAF50', '#2196F3', '#9C27B0'])
        plt.ylabel('')
        plt.title('Call Type Distribution')
        buf3 = io.BytesIO()
        plt.savefig(buf3, format='png'); buf3.seek(0)
        graphs['pie'] = base64.b64encode(buf3.getvalue()).decode()
        plt.close()

        # Daily calls line (matplotlib) for the PDF
        daily_calls_series = df.groupby(df['date'].dt.date)['duration'].count()
        plt.figure(figsize=(8, 4))
        daily_calls_series.plot(kind='line', marker='o', color='#9C27B0')
        plt.ylabel('Total Calls')
        plt.xlabel('Date')
        plt.title('Daily Total Calls')
        plt.tight_layout()
        buf4 = io.BytesIO()
        plt.savefig(buf4, format='png'); buf4.seek(0)
        graphs['line'] = base64.b64encode(buf4.getvalue()).decode()
        plt.close()

        processed_data['graphs'] = graphs

        # -------------------- Chart.js configs (must be pure JSON types) --------------------
        charts = {}

        # Daily Calls (labels as strings)
        daily_calls_df = (
            df.groupby(df['date'].dt.date)['duration']
              .count()
              .reset_index()
              .rename(columns={'duration': 'count'})
        )
        charts['dailyCalls'] = {
            'type': 'line',
            'data': {
                'labels': [str(d) for d in daily_calls_df['date'].tolist()],
                'datasets': [{
                    'label': 'Total Calls',
                    'data': [int(v) for v in daily_calls_df['count'].tolist()],
                    'borderColor': '#9C27B0',
                    'backgroundColor': 'rgba(156,39,176,0.2)',
                    'fill': True,
                    'tension': 0.4
                }]
            },
            'options': {
                'responsive': True,
                'plugins': {'legend': {'position': 'top'}}
            }
        }

        # Daily Duration
        daily_duration_df = (
            df.groupby(df['date'].dt.date)['duration']
              .sum()
              .reset_index()
        )
        charts['dailyDuration'] = {
            'type': 'line',
            'data': {
                'labels': [str(d) for d in daily_duration_df['date'].tolist()],
                'datasets': [{
                    'label': 'Total Duration (min)',
                    'data': [float(v) for v in daily_duration_df['duration'].tolist()],
                    'borderColor': '#2196F3',
                    'backgroundColor': 'rgba(33,150,243,0.2)',
                    'fill': True,
                    'tension': 0.4
                }]
            },
            'options': {
                'responsive': True,
                'plugins': {'legend': {'position': 'top'}}
            }
        }

        # Monthly Calls
        monthly_calls_df = (
            df.groupby(df['date'].dt.to_period('M'))['duration']
              .count()
              .reset_index()
              .rename(columns={'duration': 'count', 'date': 'period'})
        )
        monthly_calls_df['period'] = monthly_calls_df['period'].astype(str)
        charts['monthlyCalls'] = {
            'type': 'line',
            'data': {
                'labels': monthly_calls_df['period'].tolist(),
                'datasets': [{
                    'label': 'Total Calls',
                    'data': [int(v) for v in monthly_calls_df['count'].tolist()],
                    'borderColor': '#4CAF50',
                    'backgroundColor': 'rgba(76,175,80,0.2)',
                    'fill': True,
                    'tension': 0.4
                }]
            },
            'options': {
                'responsive': True,
                'plugins': {'legend': {'position': 'top'}}
            }
        }

        # Monthly Duration
        monthly_duration_df = (
            df.groupby(df['date'].dt.to_period('M'))['duration']
              .sum()
              .reset_index()
              .rename(columns={'date': 'period'})
        )
        monthly_duration_df['period'] = monthly_duration_df['period'].astype(str)
        charts['monthlyDuration'] = {
            'type': 'line',
            'data': {
                'labels': monthly_duration_df['period'].tolist(),
                'datasets': [{
                    'label': 'Total Duration (min)',
                    'data': [float(v) for v in monthly_duration_df['duration'].tolist()],
                    'borderColor': '#FF5722',
                    'backgroundColor': 'rgba(255,87,34,0.2)',
                    'fill': True,
                    'tension': 0.4
                }]
            },
            'options': {
                'responsive': True,
                'plugins': {'legend': {'position': 'top'}}
            }
        }

        # Call Type doughnut (for Chart.js)
        ctc = df['call_type'].value_counts()
        charts['callType'] = {
            'type': 'doughnut',
            'data': {
                'labels': [str(k) for k in ctc.index.tolist()],
                'datasets': [{
                    'label': 'Calls',
                    'data': [int(v) for v in ctc.tolist()],
                    # Colors are fine as strings in JSON
                    'backgroundColor': ['#FF5722', '#4CAF50', '#2196F3', '#9C27B0', '#FFC107']
                }]
            },
            'options': {'responsive': True}
        }

        processed_data['charts'] = charts  # keep raw dict for reference if needed

        # For your result.html which does: const charts = {{ charts|tojson }};
        # We pass 'charts' as a pure-Python dict — fully JSON-serializable now.
        # Also, provide df records for heatmap (template can do tojson safely).
        df_records = result_df.copy()
        # Ensure 'date' is ISO strings so JS Date(...) works consistently
        df_records['date'] = df_records['date'].dt.strftime('%Y-%m-%dT%H:%M:%S')
        df_records_list = df_records.to_dict(orient='records')

        return render_template(
            "result.html",
            summary=summary,
            top_callers=top_callers,
            top_callers_table=[top_callers.to_html(classes="data", index=False)],
            tables=[result_df.to_html(classes="data", index=False)],
            charts=charts,                       # <- dict that Jinja |tojson can handle
            processed_data={'df': df_records_list},  # <- safe for {{ ...|tojson }}
            kpi=kpi_data
        )

    except Exception as e:
        return f"Error processing file: {e}"

# -------------------- Download routes --------------------
@app.route('/download/csv')
def download_csv():
    if 'df' not in processed_data:
        return "No data available"
    buffer = io.StringIO()
    processed_data['df'].to_csv(buffer, index=False)
    buffer.seek(0)
    return send_file(
        io.BytesIO(buffer.getvalue().encode()),
        mimetype='text/csv',
        as_attachment=True,
        download_name="analysis.csv"
    )

@app.route('/download/excel')
def download_excel():
    if 'df' not in processed_data:
        return "No data available"
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
        processed_data['df'].to_excel(writer, index=False, sheet_name="Detailed Data")
        processed_data['summary'].to_excel(writer, index=False, sheet_name="Summary")
        processed_data['top_callers'].to_excel(writer, index=False, sheet_name="Top Callers")
    buffer.seek(0)
    return send_file(
        buffer,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name="analysis.xlsx"
    )

@app.route('/download_pdf')
@app.route('/download/pdf')
def download_pdf():
    if 'df' not in processed_data:
        return "No data available"
    tmpfile = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
    doc = SimpleDocTemplate(tmpfile.name, pagesize=(800, 1000))
    styles = getSampleStyleSheet()
    elements = []

    elements.append(Paragraph("📑 Telecom Call Records Analysis Report", styles['Title']))
    elements.append(Spacer(1, 20))

    elements.append(Paragraph("Summary per Caller", styles['Heading2']))
    summary_df = processed_data['summary']
    summary_data = [summary_df.columns.tolist()] + summary_df.astype(str).values.tolist()
    summary_table = Table(summary_data, repeatRows=1)
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#4CAF50')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.black),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold')
    ]))
    elements.append(summary_table)
    elements.append(Spacer(1, 20))

    for title, graph in processed_data.get('graphs', {}).items():
        elements.append(Paragraph(title.capitalize() + " Graph", styles['Heading2']))
        img_data = base64.b64decode(graph)
        img_tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
        img_tmp.write(img_data); img_tmp.close()
        elements.append(RLImage(img_tmp.name, width=500, height=300))
        elements.append(Spacer(1, 20))

    doc.build(elements)
    return send_file(tmpfile.name, as_attachment=True, download_name="analysis.pdf")

if __name__ == "__main__":
    app.run(debug=True)
